if whitelist() then
elseif blacklist() then
elseif denycc() then
elseif argsWaf() then
elseif cookieWaf() then
elseif urlWaf() then
else
    if ngx.req.get_method() == "POST" then
	if  get_boundary() then
		upLoadCheck()
	end
    end
end
