--config from redis to local file
local dkjson = require "dkjson"
local upload = require "resty.upload"
local Configfile = "/usr/local/openresty/nginx/conf/lua/config.json"
local rediscmd = "redis-cli -h 192.168.1.29 -p 6379 "
logpath = "/var/log/moligine/"
rulepath = "/usr/local/openresty/nginx/conf/waf/wafconf/"

function writeConfig(Configfile,msg)
    local fd = io.open(Configfile,"w")
    if fd == nil then return end
    fd:write(msg)
    fd:flush()
    fd:close()
end

function write(logfile,msg)
    local fd = io.open(logfile,"ab")
    if fd == nil then return end
    fd:write(msg)
    fd:flush()
    fd:close()
end

function clearFile(file)
	local fd = io.open(file,"w")
	if fd == nil then return end
	fd:write("")
	fd:flush()
    fd:close()
end

local cmd = rediscmd.."get globalConfig"
local confContent = io.popen(cmd)
local content = confContent:read("*a")
confContent:close()
writeConfig(Configfile,content)

--read config from local file
local localConfigFile = io.open(Configfile, "r")
assert(localConfigFile)
local gobalConfig = localConfigFile:read("*a")
localConfigFile:close()

local gobalConfigObj =  dkjson.decode(gobalConfig)
function optionStatus(options)
        if gobalConfigObj[options] == "1" then
                return  true
        else
                return  false
        end
end
html = gobalConfigObj["defendHtml"]

----将redis中的规则写入本地文件
function write_rule()
	--清空规则文件
	clearFile(rulepath.."post_waf")
	clearFile(rulepath.."cookie_waf")
	clearFile(rulepath.."args_waf")
	clearFile(rulepath.."urlwaf_waf")
	
	--清空黑白名单
	clearFile(rulepath.."whiteIplist")
	clearFile(rulepath.."whiteUrllist")
	clearFile(rulepath.."blackIpList")
	clearFile(rulepath.."blackUaList")
	clearFile(rulepath.."blackUrlList")
	
	--写入args
	if argsSqlOn then
		local cmd = rediscmd.."smembers sqlInjectionRules"
		local content = io.popen(cmd)
		local value = content:read("*a")
		content:close()
		write(rulepath.."args_waf",value)
	end
	
	if argsShellOn then
		local cmd = rediscmd.."smembers shellInjectionRules"
		local content = io.popen(cmd)
		local value = content:read("*a")
		content:close()
		write(rulepath.."args_waf",value)
	end
	
	if argsXssOn then
		local cmd = rediscmd.."smembers xssInjectionRules"
		local content = io.popen(cmd)
		local value = content:read("*a")
		content:close()
		write(rulepath.."args_waf",value)
	end
	
	--写入post_waf
	if postSqlOn then
		local cmd = rediscmd.."smembers sqlInjectionRules"
		local content = io.popen(cmd)
		local value = content:read("*a")
		content:close()
		write(rulepath.."post_waf",value)
	end
	
	if postShellOn then
		local cmd = rediscmd.."smembers shellInjectionRules"
		local content = io.popen(cmd)
		local value = content:read("*a")
		content:close()
		write(rulepath.."post_waf",value)
	end
	
	if postXssOn then
		local cmd = rediscmd.."smembers xssInjectionRules"
		local content = io.popen(cmd)
		local value = content:read("*a")
		content:close()
		write(rulepath.."post_waf",value)
	end	
	
	--写入cookie
	if cookieSqlOn then
		local cmd = rediscmd.."smembers sqlInjectionRules"
		local content = io.popen(cmd)
		local value = content:read("*a")
		content:close()
		write(rulepath.."cookie_waf",value)
	end
	
	if cookieShellOn then
		local cmd = rediscmd.."smembers shellInjectionRules"
		local content = io.popen(cmd)
		local value = content:read("*a")
		content:close()
		write(rulepath.."cookie_waf",value)
	end
	
	if cookieXssOn then
		local cmd = rediscmd.."smembers xssInjectionRules"
		local content = io.popen(cmd)
		local value = content:read("*a")
		content:close()
		write(rulepath.."cookie_waf",value)
	end		
	
	--写入白名单
	if urlSqlOn then
		local cmd = rediscmd.."smembers sqlInjectionRules"
		local content = io.popen(cmd)
		local value = content:read("*a")
		content:close()
		write(rulepath.."urlwaf_waf",value)
	end
	
	if urlShellOn then
		local cmd = rediscmd.."smembers shellInjectionRules"
		local content = io.popen(cmd)
		local value = content:read("*a")
		content:close()
		write(rulepath.."urlwaf_waf",value)
	end
	
	if urlXssOn then
		local cmd = rediscmd.."smembers xssInjectionRules"
		local content = io.popen(cmd)
		local value = content:read("*a")
		content:close()
		write(rulepath.."urlwaf_waf",value)
	end		
	
	--写入规则
	if whiteListOn then
		local cmd = rediscmd.."smembers ipWhiteList"
		local content = io.popen(cmd)
		local value = content:read("*a")
		content:close()
		write(rulepath.."whiteIplist",value)
		
		local cmd = rediscmd.."smembers urlWhiteList"
		local content = io.popen(cmd)
		local value = content:read("*a")
		content:close()
		write(rulepath.."whiteUrllist",value)
	end
	
	--写入黑名单
	if blackListOn then
		local cmd = rediscmd.."smembers ipBlackList"
		local content = io.popen(cmd)
		local value = content:read("*a")
		content:close()
		write(rulepath.."blackIpList",value)
	
		local cmd = rediscmd.."smembers uaBlackList"
		local content = io.popen(cmd)
		local value = content:read("*a")
		content:close()
		write(rulepath.."blackUaList",value)
		
		local cmd = rediscmd.."smembers urlBlackList"
		local content = io.popen(cmd)
		local value = content:read("*a")
		content:close()
		write(rulepath.."blackUrlList",value)
	end
	
end

local match = string.match
local ngxmatch=ngx.re.match
local unescape=ngx.unescape_uri
local get_headers = ngx.req.get_headers

logOn= optionStatus("logOn")
defendOn= optionStatus("defendOn")
whiteListOn= optionStatus("whiteListOn")
blackListOn = optionStatus("blackListOn")
whiteListOn = optionStatus("whiteListOn")
ccDenyOn  = optionStatus("ccDenyOn")


argsXssOn = optionStatus("argsXssOn")
argsShellOn = optionStatus("argsShellOn")
argsSqlOn = optionStatus("argsSqlOn")

cookieXssOn = optionStatus("cookieXssOn")
cookieShellOn = optionStatus("cookieShellOn")
cookieSqlOn = optionStatus("cookieSqlOn")

postShellOn = optionStatus("postShellOn")
postXssOn = optionStatus("postXssOn")
postSqlOn = optionStatus("postSqlOn")

urlShellOn = optionStatus("urlShellOn")
urlXssOn = optionStatus("urlXssOn")
urlSqlOn = optionStatus("urlSqlOn")
upLoadExtOn = optionStatus("upLoadExtOn")

CCrate = gobalConfigObj["ccDenyValue"]
upLoadExtValue = gobalConfigObj["upLoadExtValue"]

write_rule()


function getClientIp()
	IP  = ngx.var.http_true_client_ip
        if IP == nil then
                IP  = ngx.var.remote_addr
        end

        if IP == nil then
                IP  = "unknown"
        end
        return IP

end


function log(method,url,data,ruletag)
    if logOn then
        local realIp = getClientIp()
        local ua = ngx.var.http_user_agent
        local servername=ngx.var.server_name
        local time=ngx.localtime()
        if ua  then
            line = realIp.." ["..time.."] \""..method.." "..servername..url.."\" \""..data.."\"  \""..ua.."\" \""..ruletag.."\"\n"
        else
            line = realIp.." ["..time.."] \""..method.." "..servername..url.."\" \""..data.."\" - \""..ruletag.."\"\n"
        end
        local filename = logpath..'/'..servername.."_"..ngx.today()..".log"
        write(filename,line)
    end
end
------------------------------------规则读取函数-------------------------------------------------------------------
function read_rule(var)
    file = io.open(rulepath..'/'..var,"r")
    if file==nil then
        return
    end
    t = {}
    for line in file:lines() do
        table.insert(t,line)
    end
    file:close()
    return(t)
end

argsrules=read_rule('args_waf')
postrules=read_rule('post_waf')
ckrules=read_rule('cookie_waf')
urirules=read_rule('urlwaf_waf')


whiteiprules=read_rule('whiteIplist')
whiteurlrules=read_rule('whiteUrllist')

blackiprules=read_rule('blackIpList')
uarules=read_rule('blackUaList')
blackurlrules=read_rule('blackUrlList')

function debug(val)
	ngx.header.content_type = "text/html"
        ngx.status = ngx.HTTP_FORBIDDEN
        ngx.say(val)
        ngx.exit(ngx.status)

end


function say_html()
    if defendOn then
        ngx.header.content_type = "text/html"
       	ngx.status = ngx.HTTP_FORBIDDEN
       	ngx.say(html)
       	ngx.exit(ngx.status)
    end
end

function fileExtCheck(ext)

	if upLoadExtOn then
		ext=string.lower(ext)
		if ext then
			if ngxmatch('.'..ext,upLoadExtValue,"isjo") then
				log(ngx.var.request_method,ngx.var.request_uri,"-","file attack with ext ")
				say_html()
			end
		end
		return false
	end
end
function Set (list)
  local set = {}
  for _, l in ipairs(list) do set[l] = true end
  return set
end


function get_boundary()
    local header = get_headers()["content-type"]
    if not header then
        return nil
    end
    if type(header) == "table" then
        header = header[1]
    end
    local m = match(header, ";%s*boundary=\"([^\"]+)\"")
    if m then
        return m
    end
    return match(header, ";%s*boundary=([^\",;]+)")
end


----------------白名单--------------
function whitelist()
	if whiteListOn then
		--ip白名单
		for _,ip in pairs(whiteiprules) do
			if ip ~="" and getClientIp()==ip then
				return true
			end
		end
		
		--url白名单
		for _,rule in pairs(whiteurlrules) do
			if rule ~="" and ngxmatch(ngx.var.request_uri,rule,"isjo") then
				return true
			end
		end
		return false
	end
end

---------------黑名单----------------
function blacklist()
	if blackListOn then
		--ua黑名单
		local ua = ngx.var.http_user_agent
		if ua ~= nil then
			for _,rule in pairs(uarules) do
				if rule ~="" and ngxmatch(ua,rule,"isjo") then
					log('UA',ngx.var.request_uri,"-","refused by black user-agent:"..rule)
					say_html()
					return true
				end
			end
		end
		
		--ip黑名单
		for _,ip in pairs(blackiprules) do
			if ip ~="" and getClientIp()==ip then
				log(ngx.var.request_method,ngx.var.request_uri,"-","refused by black ip:"..ip)
				say_html()
				return true
			end
		end

		--url黑名单
		for _,rule in pairs(blackurlrules) do
			if rule ~="" and ngxmatch(ngx.var.request_uri,rule,"isjo") then
				log(ngx.var.request_method,ngx.var.request_uri,"-","refused by black url:"..rule)
				say_html()
				return true
			end
		end
		
		return false
	end
end

--CC攻击
function denycc()
    if ccDenyOn then
        local uri=ngx.var.uri
        CCcount=tonumber(string.match(CCrate,'(.*)/'))
        CCseconds=tonumber(string.match(CCrate,'/(.*)'))
        local token = getClientIp()..uri
        local limit = ngx.shared.limit
        local req,_=limit:get(token)
        if req then
            if req > CCcount then
				log(ngx.var.request_method,ngx.var.request_uri,"-","refused by denycc")
                exit403()
                return true
            else
                 limit:incr(token,1)
            end
        else
            limit:set(token,1,CCseconds)
        end
    end
    return false
end



--get请求过滤
function argsWaf()
	if argsSqlOn or argsShellOn or argsXssOn then
		for _,rule in pairs(argsrules) do
			local args = ngx.req.get_uri_args()
			for key, val in pairs(args) do
				if type(val)=='table' then
					 local t={}
					 for k,v in pairs(val) do
						if v == true then
							v=""
						end
						table.insert(t,v)
					end
					data=table.concat(t, " ")
				else
					data=val
				end
				if data and type(data) ~= "boolean" and rule ~="" and ngxmatch(unescape(data),rule,"isjo") then
					log(ngx.var.request_method,ngx.var.request_uri,"-","refused by args:"..rule)
					say_html()
					return true
				end
			end
		end
		return false
	end
end

--post请求过滤
function body(data)
	if postShellOn or postSqlOn or postXssOn then
		for _,rule in pairs(postrules) do
			if rule ~="" and data~="" and ngxmatch(unescape(data),rule,"isjo") then
				log('POST',ngx.var.request_uri,data,"refused by postbody:"..rule)
				say_html()
				return true
			end
		end
	end
	return false
end

function bodyWaf()
	if postShellOn or postSqlOn or postXssOn then
		ngx.req.read_body()
		local args = ngx.req.get_post_args()
		if not args then
			return false
		end
		for key, val in pairs(args) do
			if type(val) == "table" then
				if type(val[1]) == "boolean" then
					return
				end
				data=table.concat(val, ", ")
			else
				data=val
			end
			if data and type(data) ~= "boolean" and body(data) then
				body(key)
			end
		end
	end
	return false
end

--cookie过滤
function cookieWaf()
	if cookieXssOn or cookieSqlOn or cookieShellOn then
		local ck = ngx.var.http_cookie
		if ck then
			for _,rule in pairs(ckrules) do
				if rule ~="" and ngxmatch(ck,rule,"isjo") then
					log(ngx.var.request_method,ngx.var.request_uri,"-","refused by cookie:"..rule)
					say_html()
				return true
				end
			end
		end
		return false
	end
end

--restful url过滤
function urlWaf()
	if urlXssOn or urlSqlOn or urlShellOn then
		local uri = ngx.var.request_uri

		for _,rule in pairs(urirules) do
			if rule ~="" and ngxmatch(uri,rule,"isjo") then
				log(ngx.var.request_method,ngx.var.request_uri,"-","refused by uri:"..rule)
				say_html()
			return true
			end
		end

		return false
	end
end


function getExtension(str)
    return str:match(".+%.(%w+)$")
end


--上传文件校验
function upLoadCheck()
	local len = string.len
	local sock, err = ngx.req.socket()
	if not sock then
		return
	end
	ngx.req.init_body(128 * 1024)
	sock:settimeout(0)
	local content_length = nil
	content_length=tonumber(ngx.req.get_headers()['content-length'])
	local chunk_size = 4096
	if content_length < chunk_size then
		chunk_size = content_length
	end
	local size = 0
	while size < content_length do
		local data, err, partial = sock:receive(chunk_size)
		data = data or partial
		if not data then
			return
		end
		ngx.req.append_body(data)
		if body(data) then
			return true
		end
		size = size + len(data)
		local m = ngxmatch(data,[[Content-Disposition: form-data; (.+); filename="(.*)\.(.*)"]],'ijo')
		if m then
			fileExtCheck(m[3])
			filetranslate = true
		else
			if ngxmatch(data,"Content-Disposition:",'isjo') then
				filetranslate = false
			end
			if filetranslate==false then
				if body(data) then
					return true
				end
			end
		end
		local less = content_length - size
		if less < chunk_size then
			chunk_size = less
		end
	end
end

