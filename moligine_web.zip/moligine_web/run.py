# -*- coding:utf-8 -*-

from app import app
import config
import sys
import redis,json
from app import pool

app.config.from_object(config)

if __name__=="__main__":
    reload(sys)
    sys.setdefaultencoding('utf8')

    # 插入管理员数据
    r = redis.Redis(connection_pool=pool)
    user = {
        'name':'admin',
        'passwd':'123456'
    }
    r.sadd("users",json.dumps(user))
    app.run(host='0.0.0.0',port=80)