# -*- coding:utf-8 -*-

redis_conf = {
    'host':'192.168.1.197',
    'port':6379,
    'db':0
}