# -*- coding:utf-8 -*-
import os,re
def reloadServer(ip):
    cmd = 'ssh moligine@%s sudo service nginx reload' %ip
    data = {}
    try:
        output = os.popen(cmd)
    except Exception,e:
        print e
        data['ip'] = ip
        data['status'] = "success"
        return data

    if not re.match(r"Reloading nginx: \[  OK  \]", output.read()):
        data['ip'] = ip
        data['status'] = "failed"
    else:
        data['ip'] = ip
        data['status'] = "success"
    return data


