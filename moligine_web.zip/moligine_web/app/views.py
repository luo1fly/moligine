# -*- coding:utf-8 -*-
from app import app,pool
from app.etc.config import redis_conf
from flask import render_template,url_for,redirect,request,flash,session
import redis,json
from remoteCmd import reloadServer

# 首页
@app.route('/')
def index():
    if session.get('username'):
        return render_template('index.html')
    return render_template("login.html")

# 登出
@app.route('/logout/')
def logout():
    session.clear()
    return redirect('/')

# 登录页
@app.route('/login',methods=['GET'])
def login():
    return render_template('login.html')

# 登录
@app.route('/doLogin/',methods=['POST'])
def doLogin():
    form = request.form
    username = form.get('username')
    password = form.get('password')
    if not username:
        flash('username should not be empty')
        return render_template('login.html')
    if not password:
        flash('password should not be empty')
        return render_template('login.html')

    r = redis.Redis(connection_pool=pool)
    users = r.smembers('users')
    for user in users:
        user = json.loads(user)
        if user.get('name') == username and user.get('passwd') == password:
            session['username'] = user.get('name')
            return redirect('/')

    flash('username or password is wrong')
    return render_template('login.html')



# nginx
@app.route('/nginx/',methods=['GET','POST','DELETE'])
def nginx():
    # 获取ip白名单规则
    if not session.get('username'):
        return render_template('login.html')

    if request.method == 'GET':
        r = redis.Redis(connection_pool=pool)
        nginxs = r.smembers('nginxs')
        nginxServers = []
        for nginx in nginxs:
            nginxServers.append(nginx)
        return render_template('nginx.html',nginxServers=nginxServers)

    # 新增ip白名单
    if request.method == 'POST':
        nginx = request.form.get('nginxIp').strip()
        if nginx:
            r = redis.Redis(connection_pool=pool)
            r.sadd("nginxs", nginx)
        return redirect(url_for('nginx'))

    # 删除ip白名单
    if  request.method == 'DELETE':
        nginx = request.form.get('nginxIp').strip()
        if nginx:
            r = redis.Redis(connection_pool=pool)
            r.srem("nginxs", nginx)
        return 'success'

#reload nginx
@app.route('/reloadNginx/',methods=['GET'])
def reloadNginx():
    if not session.get('username'):
        return render_template('login.html')

    if request.method == 'GET':
        r = redis.Redis(connection_pool=pool)
        nginxs = r.smembers('nginxs')
        results = []
        for nginx in nginxs:
            results.append(reloadServer(nginx))
        results = json.dumps(results)
        return results



# waf规则
# SQL注入
@app.route('/sqlinjection/',methods=['GET','POST','DELETE'])
def sqlInjection():
    if not session.get('username'):
        return render_template('login.html')

    # 从redis中获取SQL注入规则
    if request.method == 'GET':
        r = redis.Redis(connection_pool=pool)
        sqlRules = r.smembers('sqlInjectionRules')
        ruleList = []
        for sqlRule in sqlRules:
            ruleList.append(sqlRule)
        return render_template('sqlinjection.html',ruleList=ruleList)

    # 新增SQL注入规则
    if request.method == 'POST':
        rule = request.form.get('sqlRule').strip()
        if rule:
            r = redis.Redis(connection_pool=pool)
            r.sadd("sqlInjectionRules", rule)
        return redirect(url_for('sqlInjection'))

    # 删除规则
    if  request.method == 'DELETE':
        rule = request.form.get('sqlRule').strip()
        if rule:
            r = redis.Redis(connection_pool=pool)
            r.srem("sqlInjectionRules", rule)
        return 'success'

# shell注入
@app.route('/shellinjection/',methods=['GET','POST','DELETE'])
def shellInjection():
    if not session.get('username'):
        return render_template('login.html')

    # 获取shell注入规则
    if request.method == 'GET':
        r = redis.Redis(connection_pool=pool)
        shellRules = r.smembers('shellInjectionRules')
        ruleList = []
        for shellRule in shellRules:
            ruleList.append(shellRule)
        return render_template('shellinjection.html',ruleList=ruleList)

    # 新增shell注入规则
    if request.method == 'POST':
        rule = request.form.get('shellRule').strip()
        if rule:
            r = redis.Redis(connection_pool=pool)
            r.sadd("shellInjectionRules", rule)
        return redirect(url_for('shellInjection'))

    # 删除shell规则
    if  request.method == 'DELETE':
        rule = request.form.get('shellRule').strip()
        if rule:
            r = redis.Redis(connection_pool=pool)
            r.srem("shellInjectionRules", rule)
        return 'success'

# xss
@app.route('/xssinjection/',methods=['GET','POST','DELETE'])
def xssInjection():
    if not session.get('username'):
        return render_template('login.html')

    # 获取xss注入规则
    if request.method == 'GET':
        r = redis.Redis(connection_pool=pool)
        xssRules = r.smembers('xssInjectionRules')
        ruleList = []
        for xssRule in xssRules:
            ruleList.append(xssRule)
        return render_template('xssinjection.html',ruleList=ruleList)

    # 新增xss注入规则
    if request.method == 'POST':
        rule = request.form.get('xssRule').strip()
        if rule:
            r = redis.Redis(connection_pool=pool)
            r.sadd("xssInjectionRules", rule)
        return redirect(url_for('xssInjection'))

    # 删除shell规则
    if  request.method == 'DELETE':
        rule = request.form.get('xssRule').strip()
        if rule:
            r = redis.Redis(connection_pool=pool)
            r.srem("xssInjectionRules", rule)
        return 'success'


# ip白名单
@app.route('/ipwhitelist/',methods=['GET','POST','DELETE'])
def ipWhiteList():
    if not session.get('username'):
        return render_template('login.html')

    # 获取ip白名单规则
    if request.method == 'GET':
        r = redis.Redis(connection_pool=pool)
        whiteIps = r.smembers('ipWhiteList')
        ruleList = []
        for whiteIp in whiteIps:
            ruleList.append(whiteIp)
        return render_template('whiteiplist.html',ruleList=ruleList)

    # 新增ip白名单
    if request.method == 'POST':
        rule = request.form.get('whiteip').strip()
        if rule:
            r = redis.Redis(connection_pool=pool)
            r.sadd("ipWhiteList", rule)
        return redirect(url_for('ipWhiteList'))

    # 删除ip白名单
    if  request.method == 'DELETE':
        rule = request.form.get('whiteip').strip()
        if rule:
            r = redis.Redis(connection_pool=pool)
            r.srem("ipWhiteList", rule)
        return 'success'

# ip黑名单
@app.route('/ipblacklist/',methods=['GET','POST','DELETE'])
def ipBlackList():
    if not session.get('username'):
        return render_template('login.html')

    # 获取ip白名单规则
    if request.method == 'GET':
        r = redis.Redis(connection_pool=pool)
        blackIps = r.smembers('ipBlackList')
        ruleList = []
        for blackIp in blackIps:
            ruleList.append(blackIp)
        return render_template('blackiplist.html',ruleList=ruleList)

    # 新增ip白名单
    if request.method == 'POST':
        rule = request.form.get('blackip').strip()
        if rule:
            r = redis.Redis(connection_pool=pool)
            r.sadd("ipBlackList", rule)
        return redirect(url_for('ipBlackList'))

    # 删除ip白名单
    if  request.method == 'DELETE':
        rule = request.form.get('blackip').strip()
        if rule:
            r = redis.Redis(connection_pool=pool)
            r.srem("ipBlackList", rule)
        return 'success'



# URL黑名单
@app.route('/urlblacklist/',methods=['GET','POST','DELETE'])
def urlBlackList():
    if not session.get('username'):
        return render_template('login.html')

    # 获取url黑名单规则
    if request.method == 'GET':
        r = redis.Redis(connection_pool=pool)
        blackUrls = r.smembers('urlBlackList')
        ruleList = []
        for blackUrl in blackUrls:
            ruleList.append(blackUrl)
        return render_template('blackurllist.html',ruleList=ruleList)

    if request.method == 'POST':
        rule = request.form.get('blackurl').strip()
        if rule:
            r = redis.Redis(connection_pool=pool)
            r.sadd("urlBlackList", rule)
        return redirect(url_for('urlBlackList'))

    if  request.method == 'DELETE':
        rule = request.form.get('blackUrl').strip()
        if rule:
            r = redis.Redis(connection_pool=pool)
            r.srem("urlBlackList", rule)
        return 'success'

# user-agent黑名单
@app.route('/uablacklist/',methods=['GET','POST','DELETE'])
def uaBlackList():
    if not session.get('username'):
        return render_template('login.html')

    # 获取url黑名单规则
    if request.method == 'GET':
        r = redis.Redis(connection_pool=pool)
        blackUas = r.smembers('uaBlackList')
        ruleList = []
        for blackUa in blackUas:
            ruleList.append(blackUa)
        return render_template('blackualist.html',ruleList=ruleList)

    if request.method == 'POST':
        rule = request.form.get('blackua').strip()
        if rule:
            r = redis.Redis(connection_pool=pool)
            r.sadd("uaBlackList", rule)
        return redirect(url_for('uaBlackList'))

    if  request.method == 'DELETE':
        rule = request.form.get('blackUa').strip()
        if rule:
            r = redis.Redis(connection_pool=pool)
            r.srem("uaBlackList", rule)
        return 'success'

# url白名单
@app.route('/urlwhitelist/', methods=['GET', 'POST', 'DELETE'])
def urlWhiteList():
    if not session.get('username'):
        return render_template('login.html')

    # 获取url白名单规则
    if request.method == 'GET':
        r = redis.Redis(connection_pool=pool)
        whiteUrls = r.smembers('urlWhiteList')
        ruleList = []
        for whiteUrl in whiteUrls:
            ruleList.append(whiteUrl)
        return render_template('whiteurllist.html', ruleList=ruleList)

    # 新增url白名单
    if request.method == 'POST':
        rule = request.form.get('whiteurl').strip()
        if rule:
            r = redis.Redis(connection_pool=pool)
            r.sadd("urlWhiteList", rule)
        return redirect(url_for('urlWhiteList'))

    # 删除url白名单
    if request.method == 'DELETE':
        rule = request.form.get('whiteUrl').strip()
        if rule:
            r = redis.Redis(connection_pool=pool)
            r.srem("urlWhiteList", rule)
        return 'success'

# 全局配置
@app.route('/globalconfig/',methods=['GET','POST'])
def globalconfig():
    if not session.get('username'):
        return render_template('login.html')

    # 查询规则
    if request.method == 'GET':
        #
        r = redis.Redis(connection_pool=pool)
        globalConfig = r.get('globalConfig')
        globalConfig = json.loads(globalConfig)
        return render_template('gobalconfig.html',globalConfig = globalConfig)

    if request.method == 'POST':
        gConfig={}
        gConfig['logOn'] = request.form.get('logOn')
        gConfig['defendOn'] = request.form.get('defendOn')
        gConfig['argsSqlOn'] = request.form.get('argsSqlOn')
        gConfig['argsXssOn'] = request.form.get('argsXssOn')
        gConfig['argsShellOn'] = request.form.get('argsShellOn')
        gConfig['postSqlOn'] = request.form.get('postSqlOn')
        gConfig['postXssOn'] = request.form.get('postXssOn')
        gConfig['postShellOn'] = request.form.get('postShellOn')
        gConfig['cookieSqlOn'] = request.form.get('cookieSqlOn')
        gConfig['cookieXssOn'] = request.form.get('cookieXssOn')
        gConfig['cookieShellOn'] = request.form.get('cookieShellOn')
        gConfig['urlSqlOn'] = request.form.get('urlSqlOn')
        gConfig['urlXssOn'] = request.form.get('urlXssOn')
        gConfig['urlShellOn'] = request.form.get('urlShellOn')
        gConfig['blackListOn'] = request.form.get('blackListOn')
        gConfig['whiteListOn'] = request.form.get('whiteListOn')
        gConfig['upLoadExtOn'] = request.form.get('upLoadExtOn')
        gConfig['upLoadExtValue'] = request.form.get('upLoadExtValue')
        gConfig['ccDenyOn'] = request.form.get('ccDenyOn')
        gConfig['ccDenyValue'] = request.form.get('ccDenyValue')
        gConfig['defendHtml'] = request.form.get('defendHtml')
        print json.dumps(gConfig)
        # 将配置文件写入redis
        r = redis.Redis(connection_pool=pool)
        r.set('globalConfig', json.dumps(gConfig))
        return 'ok'





