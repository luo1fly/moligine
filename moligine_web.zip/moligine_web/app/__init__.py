# -*- coding:utf-8 -*-

from flask import Flask
from app.etc.config import redis_conf
import redis

import config
app = Flask(__name__)

app.config.from_object(config)

pool = redis.ConnectionPool(host=redis_conf.get('host'), port=redis_conf.get('port'), db=redis_conf.get('db'))

from app import models,views

